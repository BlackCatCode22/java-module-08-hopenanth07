package com.hope.springboot.demo.MyController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class MyController {
    @GetMapping("/hello")
    public String hello() {
        // This is where your code runs and returns text to the browser.
        // You can put whatever logic you want here.
        String message = "Hello from Hope Nanthavongdouangys Spring Boot app!";
        return message;
    }

    }
