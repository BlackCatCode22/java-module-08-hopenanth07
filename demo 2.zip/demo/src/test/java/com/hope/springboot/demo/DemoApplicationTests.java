package com.hope.springboot.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoApplicationTests {

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }
}